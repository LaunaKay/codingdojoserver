// <?php header("Content-type: text/javascript; charset: UTF-8");?>
// $(document).ready(function()
// {
//       alert("This code is working");
// });
